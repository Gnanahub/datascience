''' Here is a sample line of code that can be executed in Python:

print("Hello, World!")

   '''


if __name__ == '__main__':
    mystring = "Hello, World!"
    print (mystring)
