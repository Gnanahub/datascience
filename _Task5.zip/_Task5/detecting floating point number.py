for i in range(int(input())):
    n = input()
    try:
        float(n)
        if(n.find('.') == -1):
            print(False)
        elif(n[-1].isdigit()==False):
            print(False)
        else:
            print(True)
    except:
        print(False)