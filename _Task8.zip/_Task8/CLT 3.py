import math 

n = 100
mean = 500
std = 80
percent_ci = 0.95
value_ci = 0.5

ci = value_ci * (std / math.sqrt(n)) 
print(round(mean - ci, 2))
print(round(mean + ci, 2))