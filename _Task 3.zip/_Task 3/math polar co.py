import cmath
n = input()
print(abs(complex(n)))
print(cmath.phase(complex(n)))