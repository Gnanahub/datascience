from sre_parse import expand_template
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import os

path = os.path.dirname(__file__)
my_file = path+'/data/open_pubs.csv'
df = pd.read_csv(my_file, header=None, names=['Unique_id','name','address','postcode','easting','northing','latitude','longitude','District_authority'])


st.title('Pub locations')

df.latitude.replace('\\N', np.nan, inplace=True)
df.longitude.replace('\\N', np.nan, inplace=True)
df.dropna(inplace=True)


df.latitude = df.latitude.astype('float64')
df.longitude = df.longitude.astype('float64')
df['city'] = [i[-1] for i in df.address.str.split()]

in_col, out_col = st.columns(2)
in_col.text('Here is the list of all the postal codes:')
in_col.dataframe(df.District_authority.value_counts().sort_values(ascending=False), 300, 300)


town = in_col.multiselect('Enter the city you are looking for!', df.District_authority.unique(),default= ['City of Edinburgh','Glasgow City'])

if len(town)==0:
    data = df.copy()
    # st.write(data)
else:
    data = df[df.District_authority.isin(town)]
    # st.write(data)

st.map(data)

# st.dataframe(data)

# st.map(data=df)
