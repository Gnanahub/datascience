import numpy as np

a=np.array(list(map(int,input().split())))
print(np.reshape(a,(3,3)))



