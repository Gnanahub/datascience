if __name__ == "__main__":
    res = 0
    n, m = map(int, input().strip().split(' '))
    arr = list(map(int, input().strip().split(' ')))
    
    h = set(map(int, input().strip().split(' ')))
    s = set(map(int, input().strip().split(' ')))
    
    for x in arr:
        if x in h:
            res+= 1
        elif x in s:
            res -= 1
    print(res)